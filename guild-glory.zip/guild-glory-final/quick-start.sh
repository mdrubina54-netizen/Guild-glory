#!/bin/bash

# Guild Glory - Quick Start Script
# Usage: bash quick-start.sh

echo "╔════════════════════════════════════════════════════════════╗"
echo "║      🎮 GUILD GLORY - QUICK START SCRIPT                  ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Check Python installation
echo "[1/5] Checking Python installation..."
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8+"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | awk '{print $2}')
echo "✓ Python $PYTHON_VERSION found"
echo ""

# Create virtual environment
echo "[2/5] Creating virtual environment..."
if [ -d "venv" ]; then
    echo "✓ Virtual environment already exists"
else
    python3 -m venv venv
    echo "✓ Virtual environment created"
fi

# Activate virtual environment
echo "[3/5] Activating virtual environment..."
source venv/bin/activate
echo "✓ Virtual environment activated"
echo ""

# Install dependencies
echo "[4/5] Installing dependencies..."
pip install -q -r requirements.txt
if [ $? -eq 0 ]; then
    echo "✓ Dependencies installed successfully"
else
    echo "❌ Failed to install dependencies"
    exit 1
fi
echo ""

# Start application
echo "[5/5] Starting Guild Glory..."
echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║                  🚀 SERVER STARTING...                     ║"
echo "║                                                            ║"
echo "║  📍 Access at: http://localhost:5000                      ║"
echo "║                                                            ║"
echo "║  🔑 Login Credentials:                                    ║"
echo "║     Username: admin                                       ║"
echo "║     Password: admin123@#                                 ║"
echo "║                                                            ║"
echo "║  ⚠️  Press Ctrl+C to stop the server                      ║"
echo "║                                                            ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

python app.py
