# 🚀 Guild Glory - Deployment Guide

Complete step-by-step guide for deploying Guild Glory to Netlify, Heroku, and other platforms.

## 📋 Pre-Deployment Checklist

- [ ] Python 3.8+ installed
- [ ] Git repository created
- [ ] GitHub account
- [ ] Netlify account
- [ ] All files: `index.html`, `app.py`, `requirements.txt`, `accounts.json`, `guild.py`, `main.py`
- [ ] Tested locally with `python app.py`

---

## 🌐 Deployment Option 1: Netlify (Recommended)

### Step 1: Prepare Repository

```bash
# Create GitHub repository
git init
git add .
git commit -m "Initial commit: Guild Glory web application"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/guild-glory.git
git push -u origin main
```

### Step 2: Connect to Netlify

#### Via GitHub (Easiest)
1. Go to [Netlify](https://netlify.com)
2. Click "New site from Git"
3. Select "GitHub"
4. Authenticate and select your `guild-glory` repository
5. Configure build settings:
   - **Build command:** `pip install -r requirements.txt`
   - **Publish directory:** `.`
   - **Functions directory:** `functions`
6. Click "Deploy site"

#### Via Netlify CLI
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Login to Netlify
netlify login

# Deploy
netlify deploy --prod
```

### Step 3: Configure Environment Variables

1. In Netlify dashboard, go to Site settings → Build & deploy → Environment
2. Add environment variables:
   ```
   SECRET_KEY=your-secure-random-key-here
   FLASK_ENV=production
   DEBUG=False
   ```

3. Rebuild site: Site settings → Build & deploy → Trigger deploy

### Step 4: Test Deployment

- Visit your Netlify domain
- Login with: `admin` / `admin123@#`
- Test creating a guild
- Verify all functions work

---

## 🎯 Deployment Option 2: Heroku

### Step 1: Create Heroku Account

1. Sign up at [Heroku](https://heroku.com)
2. Install Heroku CLI
3. Login: `heroku login`

### Step 2: Create Heroku App

```bash
# Create app
heroku create guild-glory-app

# Set environment variables
heroku config:set SECRET_KEY=your-secret-key
heroku config:set FLASK_ENV=production
heroku config:set DEBUG=False

# Deploy
git push heroku main

# View logs
heroku logs --tail
```

### Step 3: Create Procfile

Create file named `Procfile` (no extension):
```
web: gunicorn -w 4 -b 0.0.0.0:$PORT app:app
```

### Step 4: Add to Git and Push

```bash
git add Procfile
git commit -m "Add Procfile for Heroku"
git push heroku main
```

---

## ☁️ Deployment Option 3: AWS

### Using AWS Elastic Beanstalk

```bash
# Install EB CLI
pip install awsebcli

# Initialize
eb init -p python-3.11 guild-glory

# Create environment
eb create guild-glory-env

# Deploy
eb deploy

# Open app
eb open
```

### Using AWS Lambda + API Gateway

1. Package application:
```bash
pip install -r requirements.txt -t package/
cp app.py package/
cd package && zip -r ../lambda_function.zip . && cd ..
```

2. Create Lambda function in AWS Console
3. Upload `lambda_function.zip`
4. Create API Gateway trigger
5. Configure environment variables

---

## 🐳 Deployment Option 4: Docker

### Step 1: Create Dockerfile

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

ENV FLASK_APP=app.py
ENV FLASK_ENV=production

EXPOSE 5000

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "app:app"]
```

### Step 2: Build & Run Docker

```bash
# Build image
docker build -t guild-glory .

# Run container
docker run -p 5000:5000 \
  -e SECRET_KEY=your-key \
  -e FLASK_ENV=production \
  guild-glory
```

### Step 3: Deploy to Container Service

#### Docker Hub
```bash
docker tag guild-glory YOUR_USERNAME/guild-glory:latest
docker push YOUR_USERNAME/guild-glory:latest
```

#### AWS ECS, Google Cloud Run, or Azure Container Instances
- Upload to respective container registry
- Configure as per platform documentation

---

## 🔒 Security Configuration

### Before Going Live

1. **Change Default Credentials**
   - Edit `app.py`
   - Change `ADMIN_USERNAME` and `ADMIN_PASSWORD`
   - Use strong password (20+ characters, mixed case, numbers, symbols)

2. **Generate Secret Key**
   ```python
   import secrets
   secrets.token_hex(32)  # Use output as SECRET_KEY
   ```

3. **Enable HTTPS**
   - Netlify: Automatic ✅
   - Heroku: Automatic ✅
   - AWS/Azure: Purchase SSL certificate or use Let's Encrypt

4. **Set Up Firewall Rules**
   - Restrict IP access if needed
   - Enable WAF (Web Application Firewall)
   - Configure CORS properly

5. **Rate Limiting**
   - Adjust in `app.py`:
   ```python
   rate_limiter = RateLimiter(
       max_requests=20,      # Stricter for production
       window_seconds=60
   )
   ```

6. **Logging & Monitoring**
   - Set up log aggregation (DataDog, Splunk)
   - Configure alerts
   - Monitor performance metrics

---

## 📊 Performance Optimization

### 1. Enable Compression

Add to `app.py`:
```python
from flask_compress import Compress
Compress(app)
```

Add to `requirements.txt`:
```
Flask-Compress==1.14.0
```

### 2. Database Optimization

For file storage, periodically clean old data:
```bash
# Add to cron job
python -c "import json; data=json.load(open('guild_data.json')); print(len(data['guilds']), 'guilds')"
```

### 3. Static File Caching

In `app.py`:
```python
@app.after_request
def add_cache_headers(response):
    response.cache_control.max_age = 3600
    return response
```

### 4. Minify Frontend Assets

Use build tools:
```bash
npm install -g terser
terser index.html -o index.min.html
```

---

## 🔄 Continuous Deployment

### GitHub Actions

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Netlify

on:
  push:
    branches: [ main ]

jobs:
  build:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Install dependencies
      run: pip install -r requirements.txt
    
    - name: Run tests
      run: python -m pytest
    
    - name: Deploy to Netlify
      uses: netlify/actions/cli@master
      with:
        args: deploy --prod
      env:
        NETLIFY_SITE_ID: ${{ secrets.NETLIFY_SITE_ID }}
        NETLIFY_AUTH_TOKEN: ${{ secrets.NETLIFY_AUTH_TOKEN }}
```

### GitLab CI

Create `.gitlab-ci.yml`:

```yaml
stages:
  - build
  - deploy

build:
  stage: build
  script:
    - pip install -r requirements.txt
    - python -m pytest

deploy:
  stage: deploy
  script:
    - curl -X POST $DEPLOY_WEBHOOK_URL
  only:
    - main
```

---

## 🐛 Troubleshooting Deployments

### Issue: Module Not Found

```bash
# Ensure all requirements installed
pip install -r requirements.txt

# Check Python version
python --version  # Should be 3.8+
```

### Issue: Port Already in Use

```bash
# For local testing
python app.py --port 8000
```

### Issue: Static Files Not Found

Netlify issue:
1. Check `netlify.toml` configuration
2. Ensure files in root directory
3. Clear Netlify cache: Site settings → Build & deploy → Clear cache and rebuild

### Issue: Script Execution Fails

1. Check script paths in `app.py`
2. Verify `guild.py` and `main.py` permissions:
   ```bash
   chmod +x guild.py main.py
   ```
3. Test locally first:
   ```bash
   python guild.py --help
   ```

### Issue: Rate Limiting Too Strict

Adjust `RateLimiter` in `app.py`:
```python
rate_limiter = RateLimiter(max_requests=50, window_seconds=60)
```

---

## 📱 Domain Configuration

### Add Custom Domain

#### Netlify
1. Site settings → Domain management
2. Add custom domain
3. Update DNS records with values shown
4. Wait for DNS propagation (up to 48 hours)

#### Heroku
```bash
heroku domains:add www.yourdomain.com
```

---

## 🔍 Monitoring & Maintenance

### Daily Checks
- [ ] Website responds
- [ ] Login works
- [ ] No error logs

### Weekly
- [ ] Check rate limiter stats
- [ ] Review error logs
- [ ] Verify backups

### Monthly
- [ ] Update dependencies: `pip install --upgrade -r requirements.txt`
- [ ] Security audit
- [ ] Performance review

---

## 📚 Additional Resources

- [Netlify Docs](https://docs.netlify.com)
- [Heroku Python Guide](https://devcenter.heroku.com/articles/getting-started-with-python)
- [Flask Deployment](https://flask.palletsprojects.com/en/2.3.x/deploying/)
- [Docker Docs](https://docs.docker.com)
- [OWASP Security Guide](https://owasp.org/www-project-web-security-testing-guide/)

---

**Deployment Complete! 🎉**

Your Guild Glory application is now live and ready for use.
