@echo off
REM Guild Glory - Quick Start Script for Windows
REM Usage: quick-start.bat

echo.
echo ╔════════════════════════════════════════════════════════════╗
echo ║      ^!^!GUILD GLORY - QUICK START SCRIPT^!^!                  ║
echo ╚════════════════════════════════════════════════════════════╝
echo.

REM Check Python installation
echo [1/5] Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python is not installed. Please install Python 3.8+
    echo Visit: https://www.python.org/downloads
    pause
    exit /b 1
)

for /f "tokens=2" %%i in ('python --version 2^>^&1') do set PYTHON_VERSION=%%i
echo ✓ Python %PYTHON_VERSION% found
echo.

REM Create virtual environment
echo [2/5] Creating virtual environment...
if exist venv (
    echo ✓ Virtual environment already exists
) else (
    python -m venv venv
    echo ✓ Virtual environment created
)
echo.

REM Activate virtual environment
echo [3/5] Activating virtual environment...
call venv\Scripts\activate.bat
echo ✓ Virtual environment activated
echo.

REM Install dependencies
echo [4/5] Installing dependencies...
pip install -q -r requirements.txt
if errorlevel 1 (
    echo ❌ Failed to install dependencies
    pause
    exit /b 1
)
echo ✓ Dependencies installed successfully
echo.

REM Start application
echo [5/5] Starting Guild Glory...
echo.
echo ╔════════════════════════════════════════════════════════════╗
echo ║                  ^! SERVER STARTING...                     ║
echo ║                                                            ║
echo ║  Address: http://localhost:5000                           ║
echo ║                                                            ║
echo ║  Login Credentials:                                       ║
echo ║     Username: admin                                       ║
echo ║     Password: admin123@#                                 ║
echo ║                                                            ║
echo ║  Press Ctrl+C to stop the server                          ║
echo ║                                                            ║
echo ╚════════════════════════════════════════════════════════════╝
echo.

python app.py

pause
