# 🎮 Guild Glory - Guild Management System

Professional web-based Guild Management System with multi-region support, multiple guild handling, and integrated Python automation scripts.

## ✨ Features

- 🔐 **Secure Login System**
  - Default credentials: `admin` / `admin123@#`
  - Session-based authentication with timeout
  - Anti-DDoS protection & rate limiting

- 🛡️ **Anti-DDoS Protection**
  - Rate limiting (30 requests per 60 seconds per IP)
  - IP blocking for excessive requests (5-minute lockout)
  - Disabled right-click context menu
  - Developer tools disabled

- 🌍 **Multi-Region Support**
  - Support for: IND, SG, TH, MY, VN, PH
  - Easy region switching
  - Region-based account management

- 🏰 **Guild Management**
  - Create multiple guilds
  - Set account count per guild
  - Automatic account assignment
  - Guild status tracking
  - Real-time statistics

- 👥 **Account Management**
  - Auto-load from `accounts.json`
  - Multiple account support
  - Account allocation to guilds
  - Account status display

- 🚀 **Script Execution**
  - Integrated `guild.py` execution
  - Integrated `main.py` execution
  - Real-time execution logging
  - Process status tracking

## 📋 Prerequisites

- Python 3.8+
- pip package manager
- Flask (installed via requirements.txt)
- Unix-like system (Linux/Mac) or WSL on Windows for script execution

## 🚀 Installation

### 1. **Local Setup**

```bash
# Navigate to project directory
cd guild-glory

# Install dependencies
pip install -r requirements.txt

# Run the application
python app.py
```

The application will be available at `http://localhost:5000`

### 2. **Using Python's Built-in Server**

```bash
# Simple HTTP server for static content
python -m http.server 8000

# Then run Flask in another terminal
python app.py
```

### 3. **Production Setup with Gunicorn**

```bash
# Install gunicorn
pip install gunicorn

# Run with Gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

## 🌐 Netlify Deployment

### Option 1: Netlify CLI

```bash
# Install Netlify CLI
npm install -g netlify-cli

# Login to Netlify
netlify login

# Deploy
netlify deploy --prod
```

### Option 2: GitHub Integration

1. Push code to GitHub repository
2. Connect GitHub to Netlify
3. Configure build settings:
   - Build command: `pip install -r requirements.txt`
   - Publish directory: `.`
   - Functions directory: `functions`
4. Netlify will auto-deploy on push

### Option 3: Manual Netlify Deploy

1. Go to [Netlify](https://netlify.com)
2. Select "New site from Git"
3. Connect your repository
4. Configure build settings as above
5. Deploy

## 🔧 Configuration

### Default Credentials
```
Username: admin
Password: admin123@#
```

Change credentials in `app.py`:
```python
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin123@#'  # Change this!
```

### Environment Variables

Create `.env` file:
```
SECRET_KEY=your-secret-key-here
DEBUG=False
FLASK_ENV=production
PORT=5000
```

### Rate Limiting

Adjust in `app.py`:
```python
rate_limiter = RateLimiter(
    max_requests=30,      # Max requests
    window_seconds=60     # Per 60 seconds
)
```

### Script Paths

Modify in `app.py` if scripts are in different location:
```python
# Line ~250-260
cmd = ['python3', 'guild.py', '--guild-id', guild_id, ...]
cmd = ['python3', 'main.py', '--accounts-file', ...]
```

## 📁 File Structure

```
guild-glory/
├── index.html              # Frontend UI
├── app.py                  # Flask backend
├── requirements.txt        # Python dependencies
├── netlify.toml           # Netlify configuration
├── accounts.json          # Account data
├── guild.py               # Guild join script
├── main.py                # Main automation script
└── README.md              # This file
```

## 🎮 Usage Guide

### 1. **Login**
- Enter username: `admin`
- Enter password: `admin123@#`
- Click LOGIN

### 2. **Create Guild**
- Enter Guild ID (required)
- Enter Guild Name (optional)
- Set Account Count (1-100)
- Select Region (IND, SG, TH, MY, VN, PH)
- Click CREATE GUILD

### 3. **Select Guild**
- Click "SELECT" button on guild card
- Guild will be highlighted

### 4. **Run Guild Script**
- With guild selected, click "RUN GUILD.PY"
- Script executes with selected accounts
- Monitor output in the panel

### 5. **Run Main Script**
- With guild selected, click "RUN MAIN.PY"
- Squad bot starts
- Monitor execution in the panel

## 🔐 Security Features

### Anti-DDoS Measures
1. **Rate Limiting** - 30 requests per minute per IP
2. **IP Blocking** - Auto-block for 5 minutes after limit
3. **Right-Click Disabled** - Prevent dev tools access
4. **F12 Prevention** - Block developer console
5. **Session Timeout** - 12-hour session expiry
6. **CORS Protection** - Cross-origin request validation

### Input Validation
- All inputs sanitized
- SQL injection prevention
- XSS protection
- CSRF tokens (via Flask sessions)

### Logging
- All actions logged with timestamps
- Failed login attempts tracked
- Rate limit violations recorded
- Error tracking and debugging

## 📊 API Endpoints

### Authentication
```
POST   /api/login              - User login
POST   /api/logout             - User logout
```

### Guilds
```
GET    /api/guilds             - Get all guilds
POST   /api/guilds             - Create guild
DELETE /api/guilds/<guild_id>  - Delete guild
```

### Accounts
```
GET    /api/accounts           - Get all accounts
```

### Execution
```
POST   /api/run-guild          - Execute guild.py
POST   /api/run-main           - Execute main.py
GET    /api/status/<guild_id>  - Get process status
```

### System
```
GET    /api/stats              - Get statistics
GET    /api/health             - Health check
```

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Find process using port 5000
lsof -i :5000

# Kill the process
kill -9 <PID>
```

### Script Execution Issues
- Ensure `guild.py` and `main.py` are in same directory as `app.py`
- Check file permissions: `chmod +x guild.py main.py`
- Verify Python path: `which python3`

### Database/File Issues
```bash
# Reset data
rm guild_data.json
rm token_cache.json

# File will be recreated on first run
```

### Rate Limiting Issues
- Wait 5 minutes after blocking
- Check IP: `curl ifconfig.me`
- Adjust limit in `app.py` if needed

## 🚀 Performance Tips

1. **Async Script Execution** - Scripts run in background threads
2. **Connection Pooling** - Reuse database connections
3. **Caching** - Cache guild/account data in memory
4. **Compression** - Gzip compression on responses
5. **CDN** - Use Netlify's global CDN for static files

## 📈 Scaling

### Local to Production
1. Deploy to Netlify/Heroku/AWS
2. Use environment variables for configuration
3. Set up logging aggregation
4. Monitor with uptime services
5. Use database for persistence (optional)

### Database Migration
Replace file storage with MongoDB/PostgreSQL:
```python
# In app.py, replace DataManager class
class DataManager:
    def __init__(self):
        self.db = MongoClient(os.environ['MONGO_URI'])
```

## 📞 Support

For issues or questions:
1. Check README troubleshooting section
2. Review Flask documentation
3. Check Netlify deployment guide
4. Verify account format in `accounts.json`

## ⚠️ Important Notes

- **Never** expose credentials in code
- Always use HTTPS in production
- Regularly update dependencies: `pip install --upgrade -r requirements.txt`
- Monitor rate limiter statistics regularly
- Keep backups of `guild_data.json`
- Test script paths before production deployment

## 📝 Example accounts.json Format

```json
[
  {
    "uid": "8317389851",
    "password": "AE4B10C2EDB7CCE86A4285CFCBC799C52DFFBF3C541B8576FDB9F71FD407B916",
    "name": "UNFAIR395242",
    "account_id": "18804938088",
    "region": "IND",
    "created_at": "2026-10-20 11:27:11"
  }
]
```

## 📜 License

Guild Glory Management System - All rights reserved

---

**Version:** 1.0.0  
**Last Updated:** October 21, 2026  
**Status:** ✅ Production Ready
