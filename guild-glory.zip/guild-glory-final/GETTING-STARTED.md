# 🚀 Getting Started with Guild Glory

Complete beginner's guide to set up and run Guild Glory locally and deploy to the web.

## ⚡ Quick Start (5 minutes)

### Windows Users

1. Download Python from [python.org](https://www.python.org/downloads)
2. Install with "Add Python to PATH" checked
3. Double-click `quick-start.bat`
4. Open browser to `http://localhost:5000`
5. Login with `admin` / `admin123@#`

### Mac/Linux Users

```bash
chmod +x quick-start.sh
bash quick-start.sh
```

Then open `http://localhost:5000` in your browser.

---

## 📋 Manual Setup (Step-by-Step)

### Step 1: Install Python

**Windows:**
- Download from [python.org](https://www.python.org/downloads)
- Run installer
- ✅ Check "Add Python to PATH"
- Click Install

**Mac:**
```bash
# Using Homebrew
brew install python3

# Or download from python.org
```

**Linux:**
```bash
# Ubuntu/Debian
sudo apt-get install python3 python3-pip

# CentOS/RHEL
sudo yum install python3 python3-pip
```

### Step 2: Create Project Folder

```bash
mkdir guild-glory
cd guild-glory
```

### Step 3: Copy All Files

From the release package, copy these files to your `guild-glory` folder:
- `index.html`
- `app.py`
- `requirements.txt`
- `accounts.json`
- `guild.py`
- `main.py`
- `.env.example`

### Step 4: Create Virtual Environment

**Windows:**
```cmd
python -m venv venv
venv\Scripts\activate
```

**Mac/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 5: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 6: Start Application

```bash
python app.py
```

You should see:
```
 * Running on http://127.0.0.1:5000
```

### Step 7: Open in Browser

Go to: **http://localhost:5000**

Login:
- Username: `admin`
- Password: `admin123@#`

---

## 🎮 First Steps in the Application

### 1. Explore the Dashboard

After login, you'll see:
- **Active Guilds** - Number of guilds created
- **Total Accounts** - Number of accounts loaded
- **Regions** - Number of regions available

### 2. Create Your First Guild

1. Scroll to "Guild Configuration" section
2. Enter Guild ID (e.g., `GUILD_001`)
3. Enter Guild Name (e.g., `My Guild`)
4. Set Account Count to `4` (or less for testing)
5. Select Region: `IND` (India) or another
6. Click **CREATE GUILD**

### 3. Manage Guilds

Your guild now appears in "Active Guilds" section:
- View guild details
- Click **SELECT** to choose it
- Click **DELETE** to remove it

### 4. Run Scripts

After selecting a guild:

**Option A: Run Guild Script**
- Click **RUN GUILD.PY**
- Watch the execution output
- This joins guild with selected accounts

**Option B: Run Main Script**
- Click **RUN MAIN.PY**
- Monitor the squad bot execution
- This starts the game automation

---

## 🔑 Login & Security

### Default Credentials
```
Username: admin
Password: admin123@#
```

### Change Password

1. Open `app.py` in text editor
2. Find lines ~15-16:
   ```python
   ADMIN_USERNAME = 'admin'
   ADMIN_PASSWORD = 'admin123@#'  # Change this!
   ```
3. Change the password to something strong
4. Save and restart the application

Example strong password:
```
MySecurePass2026!@#$%Admin
```

---

## 📁 File Structure Explained

```
guild-glory/
├── index.html           ← Web interface (front-end)
├── app.py              ← Server code (back-end)
├── requirements.txt    ← Python packages
├── accounts.json       ← Your bot accounts
├── guild.py            ← Guild join script
├── main.py             ← Main automation script
├── README.md           ← Documentation
├── GETTING-STARTED.md  ← This file
├── quick-start.sh      ← Auto-setup (Mac/Linux)
├── quick-start.bat     ← Auto-setup (Windows)
└── .env.example        ← Configuration template
```

---

## ⚙️ Configuration

### Configure Accounts

1. Open `accounts.json`
2. Add your accounts in this format:

```json
[
  {
    "uid": "YOUR_UID",
    "password": "YOUR_PASSWORD_HASH",
    "name": "ACCOUNT_NAME",
    "account_id": "ACCOUNT_ID",
    "region": "IND",
    "created_at": "2026-10-20 11:27:11"
  }
]
```

3. Save and restart application

### Configure Guild Script Path

If `guild.py` or `main.py` are in different location:

1. Open `app.py`
2. Find the `run_guild_script` method (around line 250)
3. Change the command path:
   ```python
   cmd = ['python3', '/path/to/guild.py', ...]
   ```

### Configure Rate Limiting

To change request limits:

1. Open `app.py`
2. Find `RateLimiter` initialization (around line 50)
3. Modify:
   ```python
   rate_limiter = RateLimiter(
       max_requests=20,      # Max 20 requests
       window_seconds=60     # Per 60 seconds
   )
   ```

---

## 🔧 Troubleshooting

### "Port 5000 already in use"

```bash
# Use different port
python app.py
# Then open http://localhost:5001 (or shown port)
```

### "ModuleNotFoundError: No module named 'flask'"

```bash
# Reinstall dependencies
pip install -r requirements.txt
```

### "guild.py not found"

Make sure `guild.py` is in the same folder as `app.py`.

Verify:
```bash
# Windows
dir guild.py

# Mac/Linux
ls -la guild.py
```

### Script won't run

Check script permissions:

```bash
# Mac/Linux
chmod +x guild.py main.py

# Verify Python path
which python3
```

### Session timeout too short

Edit `app.py`, line ~160:
```python
if datetime.now() - login_time > timedelta(hours=12):  # Change 12
```

---

## 🌐 Deploy to Web

### Quick Deploy (Easiest)

1. **Create GitHub account** at [github.com](https://github.com)

2. **Create repository:**
   ```bash
   git init
   git add .
   git commit -m "Guild Glory"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/guild-glory
   git push -u origin main
   ```

3. **Go to [Netlify](https://netlify.com)**
   - Click "New site from Git"
   - Connect GitHub
   - Select your repository
   - Deploy!

Your app is now live at a Netlify URL!

### Custom Domain

After deploying:
1. Buy domain from [Namecheap](https://namecheap.com) or [GoDaddy](https://godaddy.com)
2. Add to Netlify (Site settings → Domain)
3. Update DNS records

---

## 📊 Performance

### Tips for Better Performance

1. **Close unnecessary programs** - Frees up RAM
2. **Use latest Python** - Faster execution
3. **SSD is better** - Faster data access
4. **Good internet** - Faster API calls

### Monitor Performance

In terminal after starting app:
- Watch CPU usage
- Watch memory usage
- Check if scripts run smoothly

---

## 🆘 Getting Help

### Check These First

1. **Did you install all files?**
   - Check all files are present
   - Compare with file list above

2. **Did you install Python?**
   ```bash
   python --version  # Should show 3.8+
   ```

3. **Did you install dependencies?**
   ```bash
   pip list  # Should show Flask, flask-cors, etc.
   ```

4. **Are scripts in correct location?**
   ```bash
   ls -la *.py  # Should show all scripts
   ```

### Common Issues

| Problem | Solution |
|---------|----------|
| Can't start app | Restart terminal, reinstall Python |
| Can't login | Check username/password in app.py |
| Scripts don't run | Put scripts in same folder |
| Slow performance | Close other programs, restart |
| Port in use | Change port in app.py |

---

## 📚 Learn More

- [Python Documentation](https://docs.python.org/3/)
- [Flask Documentation](https://flask.palletsprojects.com/)
- [Netlify Documentation](https://docs.netlify.com/)
- [Git Documentation](https://git-scm.com/doc)

---

## ✅ Checklist for Production

Before making your app public:

- [ ] Changed default admin password
- [ ] Set strong SECRET_KEY
- [ ] Configured firewall rules
- [ ] Enabled HTTPS
- [ ] Set up logging
- [ ] Tested rate limiting
- [ ] Backed up accounts.json
- [ ] Monitored server logs
- [ ] Set up auto-restart
- [ ] Have disaster recovery plan

---

## 🎉 You're Ready!

Your Guild Glory system is now ready to use. Enjoy managing your guilds!

### Next Steps

1. Create guilds
2. Assign accounts
3. Run scripts
4. Deploy to web
5. Share with team

---

**Questions?** Check README.md or deployment-guide.md

**Happy Guilding! ⚔️**
